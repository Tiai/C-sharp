﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class Chat : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Application["content"] == null) //初次登入聊天是清空
            {
                Application["content"] = "";
            }
        }

        if(Session["login"] != null) //若是會員登入
        {
            Name.Text = Session["user"].ToString();
            Guestuser.Visible = false;
            Button3.Visible = true; //可登出
            Button5.Visible = true; //可選管理者

            SqlDataSource1.SelectCommand = "SELECT Manager FROM Account " + "WHERE Username='" + Session["user"] + "'";
            DataView dv = ((DataView)SqlDataSource1.Select(new DataSourceSelectArguments()));
            if ((Convert.ToInt32(dv.Table.Rows[0][0]) == 1)) //管理者登入
            {
                Button2.Visible = true; //可清聊天室
            }
        }

        if (Session["login"] == null) //訪客登入
        {
            Guestuser.Visible = true;
            Button4.Visible = true;
        }

        OnlinePeople(sender, e);
    }

    protected void OnlinePeople(object sender, EventArgs e)//計算在線會員人數
    {
        SqlDataSource1.SelectCommand = "SELECT Username ,Online FROM Account WHERE Online=1";
        DataView dv = ((DataView)SqlDataSource1.Select(new DataSourceSelectArguments()));
        Application.Lock();
        Application["count"] = dv.Table.Rows.Count.ToString();
        Application.UnLock();
        Count.Text = Application["count"].ToString();
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {
        TextBox1.Text = Application["content"].ToString();//Timer,每秒更新一次聊天內容
    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        if (Message.Text != "")//判斷輸入內容是否為空白，是就不做事
        {
            if (Guestuser.Text == "" && Guestuser.Visible == true)//訪客留言且判斷暱稱是否為空白，是就為預設Guest
            {
                Application["content"] = Application["content"] + "\n" + "Guest" + "(" + DateTime.Now + ")" + ":" + Message.Text;
            }
            else if(Guestuser.Text != "" && Guestuser.Visible == true) //訪客暱稱留言
            {
                Application["content"] = Application["content"] + "\n" + Guestuser.Text + "(" + DateTime.Now + ")" + ":" + Message.Text;
            }
            else if(Guestuser.Visible != true)
            {
                Application["content"] = Application["content"] + "\n" + Session["user"] + "(" + DateTime.Now + ")" + ":" + Message.Text;
            }

            Message.Text = ""; //清除內容
        }
    }
    protected void Button2_Click(object sender, EventArgs e)
    {
        Application["content"] = ""; //清除所有聊天內容
    }


    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlDataSource1.UpdateCommand = "UPDATE Account SET Online=0" + "WHERE Username ='" + Session["user"] + "'"; //改為離線
        SqlDataSource1.Update();

        Session.Abandon(); //捨棄登入資訊

        OnlinePeople(sender, e);

        Button2.Visible = false;
        Button3.Visible = false;
        Button4.Visible = false;
        Button5.Visible = false;

        Response.Redirect("Login.aspx");
    }

    protected void Button4_Click(object sender, EventArgs e)
    {
        Button4.Visible = false;
        Session.Abandon();
        Response.Redirect("Login.aspx");
    }


    protected void Button5_Click(object sender, EventArgs e)
    {
        Response.Redirect("Vote.aspx");
    }
}
