﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Vote : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Visible = false;
        Label4.Visible = false;
        Label5.Visible = false;
        Label6.Visible = false;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        if(Session["login"]!=null) //會員才能投票
        {
            SqlDataSource1.SelectCommand = "SELECT Ticket FROM Account WHERE Username ='" + Session["user"] + "'"; //每會員只能投一次
            DataView dv = ((DataView)SqlDataSource1.Select(new DataSourceSelectArguments()));
            if (dv.Table.Rows[0][0].ToString().Equals("0"))
            {
                SqlDataSource1.UpdateCommand = "UPDATE Account SET Ticket=1" + "WHERE Username ='" + Session["user"] + "'"; //記錄執行過投票功能
                SqlDataSource1.Update();
                SqlDataSource1.UpdateCommand = "UPDATE Account SET Count = Count+1 " + "WHERE Username ='" + TextBox1.Text + "'"; //所支持人票數+1
                SqlDataSource1.Update();
                Label6.Visible = true;
            }
            else
            {
                Label3.Visible = true;
            }

        }
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChatRoom.aspx");
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        SqlDataSource1.SelectCommand = "SELECT Username FROM Account WHERE Manager=1"; //卸除舊管理者
        DataView dv = ((DataView)SqlDataSource1.Select(new DataSourceSelectArguments()));
        if (dv.Table.Rows.Count == 1)
        {
            SqlDataSource1.UpdateCommand = "UPDATE Account SET Manager=0" + "WHERE Username ='" + dv.Table.Rows[0][0].ToString() + "'";
        }

        SqlDataSource1.SelectCommand = "SELECT TOP 1 Count FROM Account ORDER BY Count DESC"; // 票數最高為Mod
        DataView dv2 = ((DataView)SqlDataSource1.Select(new DataSourceSelectArguments()));
        int num = Convert.ToInt32(dv2.Table.Rows[0][0]);
        if (num != 0) //排除沒人投時
        {
            SqlDataSource1.SelectCommand = "SELECT Username FROM Account " + "WHERE Count='" + num.ToString() + "'"; //找出最高票者
            DataView dv3 = ((DataView)SqlDataSource1.Select(new DataSourceSelectArguments()));
            Label4.Visible = true;
            Label5.Visible = true;
            Label5.Text = dv3.Table.Rows[0][0].ToString();

            SqlDataSource1.UpdateCommand = "UPDATE Account SET Manager=1" + "WHERE Username ='" + dv3.Table.Rows[0][0].ToString() + "'"; //更新最高票管理者資訊
            SqlDataSource1.Update();
        }

    }
}