﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Label3.Visible = false;
        Label4.Visible = false;
        Label5.Visible = false;
        Label6.Visible = false;
        Label9.Visible = false;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Redirect("ChatRoom.aspx");
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        try
        {
            Label3.Visible = false; //註冊成功標籤
            Label4.Visible = false; //註冊失敗標籤
            Label5.Visible = false; //帳號不存在標籤
            Label6.Visible = false; //密碼錯誤標籤

            Session["user"] = TextBox1.Text; //保存帳號資訊
            Session["pass"] = TextBox2.Text; //保存密碼資訊
            Session["login"] = "1"; //保存會員資訊

            bool av = true;

            SqlDataSource1.SelectCommand = "SELECT Username, Password FROM Account WHERE Username ='" + TextBox1.Text + "'"; //找該會員名稱
            DataView dv = ((DataView)SqlDataSource1.Select(new DataSourceSelectArguments()));
            if (dv.Table.Rows.Count == 0) //沒找到
            {
                av = false;
                Label5.Visible = true;
                Session.Abandon();
            }
            if (av) //有找到
            {
                if (TextBox2.Text.Equals(dv.Table.Rows[0][1].ToString())) //確認密碼是否正確
                {
                    SqlDataSource1.UpdateCommand = "UPDATE Account SET Online=1" + "WHERE Username ='" + TextBox1.Text + "'"; //上線資訊改為上線
                    SqlDataSource1.Update();
                    Response.Redirect("ChatRoom.aspx");
                }

                else
                {
                    Label6.Visible = true;
                    Session.Abandon();
                }
            }
        }
        catch
        {
            Label9.Visible = true;
        }

    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        Label5.Visible = false;
        Label6.Visible = false;

        string name = TextBox1.Text;
        string pass = TextBox2.Text;

        if (TextBox1.Text != "" && TextBox2.Text != "") //帳號密碼不為空
        {
            try
            {
                SqlDataSource1.InsertCommand = "INSERT INTO Account(Username, Password, Manager, Online, Ticket, Count)" + "VALUES(N'" + name + "', N'" + pass + "', 0, 0, 0, 0)"; //合法帳密加入資料庫
                SqlDataSource1.Insert();
                Label3.Visible = true;
                Label4.Visible = false;
            }
            catch
            {
                Label8.Visible = false; //重覆帳號
                Label3.Visible = false;
                Label4.Visible = true;
            }
        }

        else
        {
            Label8.Visible = true;
            Label3.Visible = false;
            Label4.Visible = true;
        }
    }
}